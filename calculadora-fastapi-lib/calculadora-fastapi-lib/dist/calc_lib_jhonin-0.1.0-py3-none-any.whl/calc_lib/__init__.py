from .funcoes import adicao, subtracao, multiplicacao, divisao, potencia, raiz
